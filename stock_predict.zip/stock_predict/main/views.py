from django.shortcuts import render

def index(request):
    return render(request, 'main/index.html', {})
def about_us(request):
    return render(request, 'main/about_us.html',{})
def services(request):
    return render(request, 'main/services.html',{})
